﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Entities
{
    [Serializable]
    public class Customr
    {
        public string BillId { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string ProductType { get; set; }
        public int Price { get; set; }
        public DateTime DeliveryDate { get; set; }
        public DateTime PurchasedDate { get; set; }
    }
}
