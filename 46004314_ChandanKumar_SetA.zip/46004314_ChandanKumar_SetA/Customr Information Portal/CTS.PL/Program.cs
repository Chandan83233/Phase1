﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CTS.Entities;
using CTS.Exception;
using CTS.BL;

namespace CTS.PL
{
    class Program
    {
        public static void AddCustomr()
        {
            Customr cts = new Customr();

            try
            {
                Console.Write("Enter Employee ID : ");
                cts.BillId = Console.ReadLine();
                Console.Write("Enter Customer Name : ");
                cts.CustomerName = Console.ReadLine();
                Console.Write("Enter Address : ");
                cts.Address = (Console.ReadLine());
                Console.Write("Enter City : ");
                cts.City = (Console.ReadLine());
                Console.Write("Enter Product Type : ");
                cts.ProductType = (Console.ReadLine());
                Console.Write("Enter price : ");
                cts.Price = int.Parse(Console.ReadLine());
                Console.Write("Enter purchase date : ");
                cts.PurchasedDate = DateTime.Parse(Console.ReadLine());
                Console.Write("Enter delivery date : ");
                cts.DeliveryDate = DateTime.Parse(Console.ReadLine());


                bool ctsAdded = CustomrBL.AddCustomr(cts);

                if (ctsAdded)
                {
                    Console.WriteLine("Employee Added Successfully");
                }
                else
                    throw new CustomrException("Employee Details not Added");

            }
            catch (CustomrException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateCustomr()
        {
            Customr cts = new Customr();

            try
            {
                Console.Write("Enter Employee ID to be Updated : ");
                cts.BillId = Console.ReadLine();
                Console.Write("Enter Customer Name to be Updated : ");
                cts.CustomerName = Console.ReadLine();
                Console.Write("Enter Address to be Updated: ");
                cts.Address = (Console.ReadLine());
                Console.Write("Enter City to be Updated: ");
                cts.City = (Console.ReadLine());
                Console.Write("Enter Product Typeto be Updated : ");
                cts.ProductType = (Console.ReadLine());
                Console.Write("Enter price to be Updated : ");
                cts.Price = int.Parse(Console.ReadLine());
                Console.Write("Enter purchase dateto be Updated : ");
                cts.PurchasedDate = DateTime.Parse(Console.ReadLine());
                Console.Write("Enter delivery date to be Updated : ");
                cts.DeliveryDate = DateTime.Parse(Console.ReadLine());

                bool ctsUpdated = CustomrBL.UpdateCustomr(cts);

                if (ctsUpdated)
                {
                    Console.WriteLine("Employee Updated Successfully");
                }
                else
                    throw new CustomrException("Employee Details not Updated");

            }
            catch (CustomrException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeleteCustomr()
        {
            string id;

            try
            {
                Console.Write("Enter Customer ID to be Deleted : ");
                id = (Console.ReadLine());

                bool ctsdeleted = CustomrBL.DeleteCustomr(id);

                if (ctsdeleted)
                {
                    Console.WriteLine("Customer Deleted Successfully");
                }
                else
                    throw new CustomrException("Employee not deleted");
            }
            catch (CustomrException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchCustomr()
        {
            string id;
            Customr emp = null;

            try
            {
                Console.Write("Enter  billID to be Searched : ");
                id = (Console.ReadLine());

                emp = CustomrBL.SearchCustomr(id);

                if (emp != null)
                {
                    Console.WriteLine("ustomr ID : " + emp.BillId);
                    Console.WriteLine(" Name : " + emp.CustomerName);
                    Console.WriteLine("Address : " + emp.Address);
                    Console.WriteLine("city : " + emp.City);
                    Console.WriteLine("Product type : " + emp.ProductType);
                    Console.WriteLine("price : " + emp.Price);
                    Console.WriteLine("Purchase date : " + emp.PurchasedDate);
                    Console.WriteLine("Delivery date : " + emp.DeliveryDate);
                }
                else
                    throw new CustomrException("cuatomer not found");
            }
            catch (CustomrException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void RetrieveCustomr()
        {
            try
            {
                List<Customr> empList = CustomrBL.RetrieveCustomrs();

                if (empList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("BillID        Customer Name         Address      City      prodoct type       purchse date    delivery date");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Customr emp in empList)
                    {
                        Console.WriteLine($"{emp.BillId} \t {emp.CustomerName} \t {emp.Address} \t {emp.City}\t {emp.ProductType}\t {emp.ProductType}\t {emp.DeliveryDate}");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomrException("customer Details not Available");
                }
            }
            catch (CustomrException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }



        }
        public static void SerializeEmployee()
        {
            try
            {
                bool empSerialized = CustomrBL.SerializeCustomr();

                if (empSerialized)
                {
                    Console.WriteLine("customer details serialized successfully");
                }
                else
                {
                    throw new CustomrException("customer Details not Serialized");
                }
            }
            catch (CustomrException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeserializeCustomer()
        {
            try
            {
                List<Customr> empList = CustomrBL.DeserializeCustomr();

                if (empList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Employee ID        Employee Name          Date of Joining    Salary");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Customr emp in empList)
                    {
                        Console.WriteLine($"{emp.BillId} \t {emp.CustomerName}\t{emp.Address} \t {emp.City}\t {emp.ProductType}\t {emp.ProductType}\t {emp.DeliveryDate}");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new CustomrException("Employee Details not Deserialized");
                }
            }
            catch (CustomrException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("1. Add customr");
            Console.WriteLine("2. Update customr");
            Console.WriteLine("3. Delete customr");
            Console.WriteLine("4. Search customr");
            Console.WriteLine("5. Retrieve customr");
            Console.WriteLine("6. Serialize customr");
            Console.WriteLine("7. Deserialize customr");
            Console.WriteLine("8. Exit");
            Console.WriteLine("**************************");
        }


        static void Main(string[] args)
        {
            int choice;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCustomr();
                            break;
                        case 2:
                            UpdateCustomr();
                            break;
                        case 3:
                            DeleteCustomr();
                            break;
                        case 4:
                            SearchCustomr();
                            break;
                        case 5:
                            RetrieveCustomr();
                            break;
                        case 6:
                            SerializeEmployee();
                            break;
                        case 7:
                            DeserializeCustomer();
                            break;

                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Please make valid choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}




