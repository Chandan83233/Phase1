﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using CTS.Entities;
using CTS.Exception;

namespace CTS.DAL
{
    public class CustomrDAL
    {
        static List<Customr> ctsList = new List<Customr>();
        public static bool AddCustomr(Customr cts)
        {
            bool ctsAdded = false;

            try
            {
                ctsList.Add(cts);
                ctsAdded = true;
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsAdded;
        }
        public static bool UpdateCustomr(Customr cts)
        {
            bool ctsUpdated = false;

            try
            {
                for (int i = 0; i < ctsList.Count; i++)
                {
                    if (ctsList[i].BillId == cts.BillId)
                    {
                        ctsList[i].CustomerName = cts.CustomerName;
                        ctsList[i].Address = cts.Address;
                        ctsList[i].City = cts.City;
                        ctsList[i].ProductType = cts.ProductType;
                        ctsList[i].Price = cts.Price;
                        ctsList[i].DeliveryDate = cts.DeliveryDate;
                        ctsList[i].PurchasedDate = cts.PurchasedDate;
                        ctsUpdated = true;
                    }
                }
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsUpdated;
        }
        public static bool DeleteCustomr(string id)
        {
            bool ctsDeleted = false;

            try
            {
                Customr cts = ctsList.Find(e => e.BillId == id);

                if (cts != null)
                {
                    ctsList.Remove(cts);
                    ctsDeleted = true;
                }
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsDeleted;
        }
        public static Customr SearchCustomr(string id)
        {
            Customr cts = null;

            try
            {
                cts = ctsList.Find(e => e.BillId == id);
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cts;
        }
        public static List<Customr> RetrieveCustomrs()
        {
            return ctsList;
        }
        public static bool SerializeCustomr()
        {
            bool ctsSerialized = false;

            try
            {
                FileStream fs = new FileStream("Emp.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(fs, ctsList);
                fs.Close();
                ctsSerialized = true;
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsSerialized;
        }
        public static List<Customr> DeserializeCustomr()
        {
            List<Customr> desEmpList = null;

            try
            {
                FileStream fs = new FileStream("Emp.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desEmpList = bin.Deserialize(fs) as List<Customr>;
                fs.Close();
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desEmpList;
        }
    }
}
