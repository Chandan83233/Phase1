﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using CTS.Entities;
using CTS.Exception;
using CTS.DAL;

namespace CTS.BL
{
    public class CustomrBL
    {
        public static bool ValidateCustomr(Customr cts)
        {
            bool ctsValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (!Regex.IsMatch(cts.BillId, @"^[A-Z]{2}[0-9]{3}$"))
                {
                    ctsValidated = false;
                    message.Append("Customer BillID should be 5 digits long With Fist two Character is upper case letter followed by digi\n");
                }
                if (cts.Price < 20000 || cts.Price > 100000)
                {
                    ctsValidated = false;
                    message.Append("price should be in range of 20k to 1 lakh\n");
                }
            

                if (cts.CustomerName.Length < 8 || cts.CustomerName.Length > 15)
                {
                    ctsValidated = false;
                    message.Append("Employee Name should be of min of 8 char and max od 15 char\n");
                }
                else if (!Regex.IsMatch(cts.CustomerName, "[A-Z][a-z]+"))
                {
                    ctsValidated = false;
                    message.Append("Employee Name should start with capital alphabet and it should have alphabets only\n");
                }
                if (cts.PurchasedDate > DateTime.Now)
                {
                    ctsValidated = false;
                    message.Append("Date of purchase should be less than or equal to current date");
                }
                if (cts.DeliveryDate > DateTime.Now)
                {
                    ctsValidated = false;
                    message.Append("Date of delivery should be less than or equal to current date");
                }
                //if (cts.DeliveryDate == cts.DeliveryDate)
                //{
                //    ctsValidated = false;
                //    message.Append("Puchase date should not be less than delivery date");
                //}
                if (ctsValidated == false)
                {
                    throw new CustomrException(message.ToString());
                }
               
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsValidated;


        }
        public static bool AddCustomr(Customr cts)
        {
            bool ctsAdded = true;

            try
            {
                if (ValidateCustomr(cts))
                {
                    ctsAdded = CustomrDAL.AddCustomr(cts);
                }
                else
                    throw new CustomrException("Please provide valida employee details");
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsAdded;
        }
        public static bool UpdateCustomr(Customr cts)
        {
            bool ctsUpdated = false;

            try
            {
                if (ValidateCustomr(cts))
                {
                    ctsUpdated = CustomrDAL.UpdateCustomr(cts);
                }
                else

                    throw new CustomrException("Please provide valid Customr details for update");

            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsUpdated;
        }
        public static bool DeleteCustomr(string id)
        {
            bool ctsDeleted = false;

            try
            {
                ctsDeleted = CustomrDAL.DeleteCustomr(id);
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsDeleted;
        }
        public static Customr SearchCustomr(string id)
        {
            Customr cts = null;

            try
            {
                cts = CustomrDAL.SearchCustomr(id);
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cts;
        }
        public static List<Customr> RetrieveCustomrs()
        {
            List<Customr> ctsList = null;

            try
            {
                ctsList = CustomrDAL.RetrieveCustomrs();
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsList;
        }
        public static bool SerializeCustomr()
        {
            bool ctsSerialized = false;

            try
            {
                ctsSerialized = CustomrDAL.SerializeCustomr();
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ctsSerialized;
        }
        public static List<Customr> DeserializeCustomr()
        {
            List<Customr> ctsList = null;

            try
            {
                ctsList = CustomrDAL.DeserializeCustomr();
            }
            catch (CustomrException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return ctsList;
        }
    }
}
