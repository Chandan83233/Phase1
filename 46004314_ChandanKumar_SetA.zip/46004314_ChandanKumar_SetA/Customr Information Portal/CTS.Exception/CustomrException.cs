﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CTS.Exception
{
    public class CustomrException:ApplicationException
    {
        public CustomrException() : base()
        { }

        public CustomrException(string message) : base(message)
        { }
    }
}
