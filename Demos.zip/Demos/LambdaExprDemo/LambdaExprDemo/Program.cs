﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExprDemo
{
    public delegate void LambdaDelgate();

    public delegate void LambdaDelegateParam(int num1, int num2);

    public delegate string LambdaDelegateReturn(string str1, string str2);
    class Program
    {
        static void Main(string[] args)
        {
            LambdaDelgate ld = () => Console.WriteLine("Lambda Expression Executed");
            //LambdaDelgate ld = () => { Console.WriteLine("Lambda Expression Executed"); };
            ld();

            //LambdaDelegateParam param = (int num1, int num2) => Console.WriteLine($"{num1} + {num2} => {num1 + num2}");
            LambdaDelegateParam param = (num1, num2) => Console.WriteLine($"{num1} + {num2} => {num1 + num2}");
            param(10, 20);

            //LambdaDelegateReturn ldReturn = (str1, str2) => { return str1 + " " + str2; };
            LambdaDelegateReturn ldReturn = (str1, str2) => str1 + " " + str2;
            Console.WriteLine("Result is : " + ldReturn(".NET", "Batch"));

            Console.ReadKey();
        }
    }
}
