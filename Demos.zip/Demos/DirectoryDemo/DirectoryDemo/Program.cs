﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DirectoryDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryInfo dir = new DirectoryInfo(@"D:\DATA");

            if (dir.Exists)
            {
                Console.WriteLine($"Directory Name : {dir.Name}");
                Console.WriteLine($"Creation Time : {dir.CreationTime}");
                Console.WriteLine($"Extension : {dir.Extension}");
                Console.WriteLine($"Full Name : {dir.FullName}");
                Console.WriteLine($"Last Access Time : {dir.LastAccessTime}");
                Console.WriteLine($"Last Write Time : {dir.LastWriteTime}");
                Console.WriteLine($"Parent : {dir.Parent}");
                Console.WriteLine($"Root : {dir.Root}");

                DirectoryInfo[] childDirs = dir.GetDirectories();
                Console.WriteLine($"\nNumber of Directories : {childDirs.Length}");
                for (int i = 0; i < childDirs.Length; i++)
                {
                    Console.WriteLine(childDirs[i].Name);
                }

                FileInfo[] childFiles = dir.GetFiles();
                Console.WriteLine($"\nNumber of Files : {childFiles.Length}");
                for (int i = 0; i < childFiles.Length; i++)
                {
                    Console.WriteLine(childFiles[i].Name);
                }
            }
            else
            {
                Console.WriteLine("Directory Does Not Exists");
            }
            Console.ReadKey();
        }
    }
}
