﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace ParallelForDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();

            Stopwatch sw = Stopwatch.StartNew();
            p.SequentialCall();
            sw.Stop();
            long seqTime = sw.ElapsedMilliseconds;

            sw = Stopwatch.StartNew();
            p.ParallelCall();
            sw.Stop();
            long parTime = sw.ElapsedMilliseconds;

            Console.WriteLine("Time taken by Sequential For : " + seqTime);
            Console.WriteLine("Time taken by Parallel For : " + parTime);

            Console.ReadKey();
        }

        public void SequentialCall()
        {
            Console.WriteLine("Sequential For Loop Started...");
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("Sequential Index : " + i);
                System.Threading.Thread.Sleep(1000);
            }
            Console.WriteLine("Sequential For Loop Completed");
        }

        public void ParallelCall()
        {
            Console.WriteLine("Parallel For Loop Started...");
            Parallel.For(0, 100, i => 
            {
                Console.WriteLine("Parallel Index : " + i);
                System.Threading.Thread.Sleep(1000);
            });
            Console.WriteLine("Parallel For Loop Completed");
        }
    }
}
