﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace MethodInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly myAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type calc = myAssembly.GetType("ReflectionLibrary.Calculate");

            MethodInfo[] methods = calc.GetMethods();

            Console.WriteLine("Number of Methods are : {0} \n", methods.Length);

            foreach (MethodInfo m in methods)
            {
                Console.WriteLine("Method Name : " + m.Name);
                Console.WriteLine("Contains Generic Parameters : " + m.ContainsGenericParameters);
                Console.WriteLine("Declaring Type : " + m.DeclaringType.Name);
                Console.WriteLine("Is Abstract : " + m.IsAbstract);
                Console.WriteLine("Is Contructor : " + m.IsConstructor);
                Console.WriteLine("Is Final : " + m.IsFinal);
                Console.WriteLine("Is Generic Method : " + m.IsGenericMethod);
                Console.WriteLine("Is Private : " + m.IsPrivate);
                Console.WriteLine("Is Public : " + m.IsPublic);
                Console.WriteLine("Is Static : " + m.IsStatic);
                Console.WriteLine("Is Virtual : " + m.IsVirtual);
                Console.WriteLine("Return Parameter : " + m.ReturnParameter);
                Console.WriteLine("Return Type : " + m.ReturnType);
                
                ParameterInfo[] param = m.GetParameters();
                Console.WriteLine("Number of Parameters : " + param.Length);
                foreach (ParameterInfo p in param)
                {
                    Console.WriteLine("Name : " + p.Name);
                    Console.WriteLine("Type : " + p.ParameterType);
                }
                Console.WriteLine("************************************************************\n");
            }

            object obj = myAssembly.CreateInstance("ReflectionLibrary.Calculate");
            MethodInfo addMethod = calc.GetMethod("Add");
            int sum = (int)addMethod.Invoke(obj, new object[] { 10, 20 });
            Console.WriteLine("Addition is : " + sum);

            MethodInfo subMethod = calc.GetMethod("Subtract");
            int sub = (int)subMethod.Invoke(null, new object[] { 76, 23 });
            Console.WriteLine("Subtraction is : " + sub);

            Console.ReadKey();
        }
    }
}
