﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActionDelegateDemo
{
    class Program
    {
        public void Show()
        {
            Console.WriteLine("Show Method Called");
        }

        public void CountDigits(string str)
        {
            int count = 0;
            for (int i = 0; i < str.Length; i++)
            {
                if (Char.IsDigit(str[i]))
                    count++;
            }

            Console.WriteLine("Number of Digits : " + count);
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            Action showDel = p.Show;
            showDel();

            Action<string> countDel = p.CountDigits;
            countDel("sddfd343sdfd4df");

            Action<int, int> addDel = delegate (int num1, int num2)
            {
                Console.WriteLine($"{num1} + {num2} => {num1 + num2}");
            };
            addDel(23, 56);

            Action<int, int> multDel = (num1, num2) => Console.WriteLine($"{num1} * {num2} => {num1 * num2}");
            multDel(32, 4);

            Console.ReadKey();
        }
    }
}
