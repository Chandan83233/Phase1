﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodDemo
{
    public delegate void AnonymousDelegate();

    public delegate void AnonymousDelegateParam(int num1, int num2);

    public delegate string AnonymousDelegateReturn(string str1, string str2);
    class Program
    {
        public static void Show()
        {
            Console.WriteLine("Show Method Called");
        }
        static void Main(string[] args)
        {
            AnonymousDelegate del = new AnonymousDelegate(Show);

            del();

            AnonymousDelegate an = delegate {
                Console.WriteLine("Anonymous Method Called");
            };

            an();

            AnonymousDelegateParam anParam = delegate (int num1, int num2) {
                Console.WriteLine($"{num1} + {num2} => {num1 + num2}");
            };

            anParam(10, 20);

            AnonymousDelegateReturn anReturn = delegate (string str1, string str2) {
                return str1 + " " + str2;
            };

            Console.WriteLine(anReturn(".NET", "Batch"));

            Console.ReadKey();
        }
    }
}
