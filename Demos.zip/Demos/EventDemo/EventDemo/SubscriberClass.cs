﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    public class SubscriberClass
    {
        public void ActionMethod(string message)
        {
            Console.WriteLine(message);
        }
    }
}
