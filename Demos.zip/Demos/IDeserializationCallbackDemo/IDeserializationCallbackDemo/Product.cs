﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace IDeserializationCallbackDemo
{
    [Serializable]
    public class Product : IDeserializationCallback
    {
        int id;
        public int ProdID
        { get { return id; } set { id = value; } }

        string name;
        public string ProdName
        { get { return name; } set { name = value; } }

        int qty;
        public int Quantity
        { get { return qty; } set { qty = value; } }

        int unitPrice;
        public int Price
        { get { return unitPrice; } set { unitPrice = value; } }

        [NonSerialized]
        int total;
        public int TotalPrice
        { get { return total; } }

        public Product(int id, string name, int qty, int price)
        {
            this.id = id;
            this.name = name;
            this.qty = qty;
            this.unitPrice = price;
            this.total = qty * price;
        }

        public void OnDeserialization(object sender)
        {
            total = qty * unitPrice;
        }

        //public void CalculateTotal()
        //{
        //    total = qty * unitPrice;
        //}
    }
}
