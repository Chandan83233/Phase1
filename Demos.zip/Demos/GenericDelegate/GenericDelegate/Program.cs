﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDelegate
{
    public delegate T GenericDelegate<T>(T val);
    class Program
    {
        public int Sum(int num)
        {
            int result = 0;

            for (int i = 0; i <= num; i++)
            {
                result = result + i;
            }

            return result;
        }

        public string Reflect(string str)
        {
            string result = "";

            for (int i = 0; i < str.Length; i++)
            {
                result = result + str;
            }
            return result;
        }
        static void Main(string[] args)
        {
            Program p = new Program();

            GenericDelegate<int> intDel = new GenericDelegate<int>(p.Sum);
            int sum = intDel(10);
            Console.WriteLine("Sum is : " + sum);

            GenericDelegate<string> strDel = new GenericDelegate<string>(p.Reflect);
            string str = strDel(".NET");
            Console.WriteLine("Reflect is : " + str);

            Console.ReadKey();
        }
    }
}
