﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public class Employee
    {
        int id;
        public int EmpID { get { return id; } set { id = value; } }

        string name;
        public string EmpName { get { return name; } set { name = value; } }

        string city;
        public string City { get { return city; } set { city = value; } }
    }
}
